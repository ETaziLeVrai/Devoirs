package fr.unice.j3.android_tp01;

public class Preferences {
    private String surnom = "Elias";

    public String obtenirSurnom() {
        return surnom;
    }
}
