package fr.unice.j3.android_tp01;

public interface Chat {
    String obtenirTextTapé() ;
    void ajouterMessage(String msg);
}
