package fr.unice.j3.android_tp01;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import fr.unice.l3.android_tp01.R;

public class ChatActivity extends Activity implements Chat {
    // pour LOG
    public static final String LOG = "TP-ANDROID-CHAT";
    // 2 <--
    EditText message;
    TextView chat;
    ScrollView scroll;
    Button envoyer;
    Préférences prefs;
    // -->
    // 3 <--
    Écouteur écouteur;
    Switch connexion;
    private char couleur;

    // 3 -->
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 2 <--

        setContentView(R.layout.activity_chat);
        message = findViewById(R.id.message);
        chat = findViewById(R.id.chat);
        scroll = findViewById(R.id.scroll);
        envoyer = findViewById(R.id.envoyer);
        // 3 Elle puisse recevoir les événements « onCheckedChanged » lié
        // 3 au switch « connexion »
        connexion = findViewById(R.id.connexion);
        // 2 Ce surnom est fourni par une instance de la classe Préférences (créée dans le onCreate)
        prefs = new Préférences();
        // 2 Écouteur écouteur = new Écouteur(this);
        // 3 écouteur partagée avec onPause et onResume
        écouteur = new Écouteur(this, prefs);
        // 2 Cet écouteur devra être associé à « envoyez » dans le onCreate de l’activité.
        envoyer.setOnClickListener(écouteur);
        // 3 Elle puisse recevoir les événements « onCheckedChanged » lié au switch « connexion
        connexion.setOnCheckedChangeListener(écouteur);
    }

    @Override
    public String obtenirTextTapé() {
        // 2 via une méthode *obtenirSurnom*
        // 2 String texte = prefs.obtenirSurnom() + " > " + message.getText() + "\n";
        // 3 le message émis au serveur contient le sur nom
        String texte = message.getText().toString();
        message.setText("");
        return texte;
    }

    @Override
    public void ajouterMessage(final String msg) {
    }

    @Override
    public void onActivityResult(int requestcode, int resultcode, Intent data) {

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.chat, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.listesconnectes) {
            écouteur.demandeCo();
        }
        return true;
    }


}