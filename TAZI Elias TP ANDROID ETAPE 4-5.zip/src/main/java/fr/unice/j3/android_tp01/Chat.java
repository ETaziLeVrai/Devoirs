package fr.unice.j3.android_tp01;

import android.content.Intent;

// 2 Créez une interface Chat qui contient deux méthodes :
public interface Chat {
    // 2 public String obtenirTextTapé() ;
    public String obtenirTextTapé() ;
    // 2 public void ajouterMessage(String msg);
    public void ajouterMessage(final String msg);
    public void onActivityResult(int requestcode, int resultcode, Intent data);
}
