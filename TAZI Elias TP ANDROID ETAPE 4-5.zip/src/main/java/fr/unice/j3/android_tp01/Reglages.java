package fr.unice.j3.android_tp01;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import fr.unice.l3.android_tp01.R;

public class Reglages extends Activity {
    EditText surnom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reglages);
        surnom.setText(getIntent().getStringExtra(Préférences.SURNOM));
    }

    // 5 Ecouter « onClick » (avec l’attribut xml) sur le bouton « retour » (pour appeler la méthode
// 5 onBackPressed)
    public void retour(View view) {
        onBackPressed();
    }

    // 5 Surcharger la méthode : public void onBackPressed() pour intercepter l’appui sur le
// 5 bouton « retour », pour retourner à l’activité ChatActivity (setResult avec un Intent
// 5 avec la valeur du prénom comme chaine de caractère)
    @Override
    public void onBackPressed() {
        Intent i = new Intent();
        i.putExtra(Préférences.SURNOM, surnom.getText().toString());
        setResult(Activity.RESULT_OK, i);
        super.onBackPressed();
    }
}