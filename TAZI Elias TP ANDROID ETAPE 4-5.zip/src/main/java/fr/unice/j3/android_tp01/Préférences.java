package fr.unice.j3.android_tp01;

import android.content.Context;
import android.content.Intent;

public class Préférences {
    public static String SURNOM = "surnom";
    public static String surnom;

    public String obtenirSurnom() {
        return surnom;
    }

    public Intent obtenirRéglages(Context c) {
        Intent i = new Intent(c, Reglages.class);
        i.putExtra(SURNOM, obtenirSurnom());
        return i;

    }

    public void reçoit(Intent data) {
        String surnom = data.getStringExtra(SURNOM);
    }
}
