package fr.unice.l3.android_tp01;
/*
@startuml
class fr.unice.l3.android_tp01.ChatActivity {
        ~ EditText message
        ~ TextView chat
        ~ ScrollView scroll
        ~ Button envoyer
        ~ <color:red>Switch connexion</color>
        # <color:green>void onCreate(Bundle)</color>
        + <color:green>String obtenirTextTapé()</color>
        + <color:green>void ajouterMessage(String)</color>
        +<color:red> void onPause()</color>
        + <color:red>void onResume()</color>
        }
interface fr.unice.l3.android_tp01.Chat{
    + String obtenirTextTapé() ;
    + void ajouterMessage(String msg);
    }
 class fr.unice.l3.android_tp01.Préférences {
- String surnom="Pierre"
+ String obtenirSurnom()
+ void changerSurnom(String)
}

class fr.unice.l3.android_tp01.Écouteur {
    + <color:red>sÉcouteur(Chat chat, Préférences préférences)</color>
        - Chat chat
        - <color:red>sPréférences préférences</color>
        + <color:red>void onClick(View)</color>
        + void setChat(Chat)
        + Chat getChat()
        + <color:red>setPréférences(Préférences préférences)</color>
        +<color:red>svoid onCheckedChanged(CompoundButton buttonView, boolean isChecked)</color>
        + <color:red>void call(Object... args)</color>
        + <color:red>void connexion()</color>
        + <color:red>void deconnexion()</color>
        }
class  android.app.Activity{
        # void onCreate(Bundle)
        # <color:blue>void onPause()</color>
        # <color:blue>void onResume()</color>
}
        fr.unice.l3.android_tp01.Chat <|.. fr.unice.l3.android_tp01.ChatActivity
        android.app.Activity <|-- fr.unice.l3.android_tp01.ChatActivity
    fr.unice.l3.android_tp01.ChatActivity ..>    fr.unice.l3.android_tp01.Écouteur : instantiate
    fr.unice.l3.android_tp01.ChatActivity *-> "1" fr.unice.l3.android_tp01.Préférences :prefs
@enduml
*/

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

public class ChatActivity extends Activity implements Chat {
    // pour LOG
    public static final String LOG = "TP-ANDROID-CHAT";
    // 2 <--
    EditText message;
    TextView chat;
    ScrollView scroll;
    Button envoyer;
    Préférences prefs;
    // -->
    // 3 <--
    Écouteur écouteur;
    Switch connexion;
    // 3 -->
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 2 <--
        setContentView(R.layout.activity_chat);
        message = findViewById(R.id.message);
        chat = findViewById(R.id.chat);
        scroll = findViewById(R.id.scroll);
        envoyer = findViewById(R.id.envoyer);
        // 3 Elle puisse recevoir les événements « onCheckedChanged » lié
        // 3 au switch « connexion »
        connexion = findViewById(R.id.connexion);
        // 2 Ce surnom est fourni par une instance de la classe Préférences (créée dans le onCreate)
        prefs = new Préférences();
        // 2 Écouteur écouteur = new Écouteur(this);
        // 3 écouteur partagée avec onPause et onResume
        écouteur = new Écouteur(this, prefs);
        // 2 Cet écouteur devra être associé à « envoyez » dans le onCreate de l’activité.
        envoyer.setOnClickListener(écouteur);
        // 3 Elle puisse recevoir les événements « onCheckedChanged » lié au switch « connexion
        connexion.setOnCheckedChangeListener(écouteur);
    }

    @Override
    public String obtenirTextTapé() {
        // 2 via une méthode *obtenirSurnom*
        // 2 String texte = prefs.obtenirSurnom() + " > " + message.getText() + "\n";
        // 3 le message émis au serveur contient le sur nom
        String texte = message.getText().toString();
        message.setText("");
        return texte;
    }

    // 3 la réception du message “chatevent” se fait sur thread de “socketIO”, il n’y a alors
    // 3 pas accès aux éléments graphiques et l’appel à la méthode ajouterMessage provoque une
    // 3 exception :
    @Override
    public void ajouterMessage(final String msg) {
        // 3 Pour éviter ce problème, il faut modifier la méthode ajouterMessage de ChatActivity en encapsulant
        // 3 son contenu dans un « runOnUIThread(new Runnable() { /* etc. */ }) ; ».
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                chat.append(msg);
                // 2 Pour faire « descendre » scroll, il faut utiliser une ligne de code ressemblent à
                scroll.fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    // 3 Pour ne pas consommer pendant que l’application n’est pas utilisée, il faut prévoir la déconnexion
    // 3 sur le onPause de ChatActivity et
    // 3 de rétablir la connexion dans le onResume si le switch connexion est sélectionné.
    @Override
    public void onPause() {
        super.onPause();
        écouteur.deconnexion();
    }

    // 3 de rétablir la connexion dans le onResume si le switch connexion est sélectionné.
    @Override
    public void onResume() {
        super.onResume();
        if (connexion.isChecked()) écouteur.connexion();
    }

}
