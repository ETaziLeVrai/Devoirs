package fr.unice.l3.android_tp01;
/*
@startuml
interface fr.unice.l3.android_tp01.Chat{
    + String obtenirTextTapé()
    + void ajouterMessage(String msg)

}
@enduml
 */
// 2 Créez une interface Chat qui contient deux méthodes :
public interface Chat {
// 2 public String obtenirTextTapé() ;
    public String obtenirTextTapé() ;
    // 2 public void ajouterMessage(String msg);
    public void ajouterMessage(String msg);
}
