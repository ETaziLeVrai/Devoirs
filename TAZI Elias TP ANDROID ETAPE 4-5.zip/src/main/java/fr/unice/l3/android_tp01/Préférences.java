package fr.unice.l3.android_tp01;
/*
@startuml
class fr.unice.l3.android_tp01.Préférences {
- String surnom="Pierre"
+ String obtenirSurnom()
+ void changerSurnom(String)
}
@enduml
 */
// 2 le surnom est fourni par une instance de la
// 2 classe *Préférences* (créée dans le *onCreate*),
public class Préférences {
    // 2 Pour l’instant, le surnom sera « écrit » en dur dans le code.
    private String surnom = "Pierre";
    // 2 via une méthode *obtenirSurnom* et .
    public String obtenirSurnom() {
        return surnom;
    }
    // 2  *changerSurnom*.
    public void changerSurnom(String surnom) {
        this.surnom = surnom;
    }
}
