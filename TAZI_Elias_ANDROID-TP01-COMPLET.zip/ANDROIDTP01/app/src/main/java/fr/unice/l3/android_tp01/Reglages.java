package fr.unice.l3.android_tp01;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Reglages extends Activity {

    EditText surnom;
    EditText serveur;
    EditText port;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reglages);
        surnom = (EditText) findViewById(R.id.editSurnom);
        surnom.setText(getIntent().getStringExtra(Préférences.SURNOM));
        serveur = findViewById(R.id.editServeur);
        serveur.setText(getIntent().getStringExtra(Préférences.SERVEUR));
        port = findViewById(R.id.editPort);
        port.setText(getIntent().getStringExtra(Préférences.PORT));

    }


    public void retour(View view) {
        onBackPressed();
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent();
        i.putExtra(Préférences.SURNOM, surnom.getText().toString());

        i.putExtra(Préférences.SERVEUR, serveur.getText().toString());
        i.putExtra(Préférences.PORT, port.getText().toString());
        setResult(Activity.RESULT_OK, i);
        super.onBackPressed();
    }
}