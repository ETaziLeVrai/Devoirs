package fr.unice.l3.android_tp01;

// 2 Créez une interface Chat qui contient deux méthodes :
public interface Chat {
// 2 public String obtenirTextTapé() ;
    public String obtenirTextTapé() ;
    // 2 public void ajouterMessage(String msg);
    public void ajouterMessage(String msg);
    // 4 Ce message doit apparaitre en rouge dans le texte. Pour cela ajoutez une méthode
    // 4 (les paramètres sont « final » pour être utiliser dans un runOnUIThread) :
    // 4 public void ajouterMessage(final String msg, final int couleur)
    public void ajouterMessage(final String msg, final int couleur);
    void activerIHM(boolean checked);

}
