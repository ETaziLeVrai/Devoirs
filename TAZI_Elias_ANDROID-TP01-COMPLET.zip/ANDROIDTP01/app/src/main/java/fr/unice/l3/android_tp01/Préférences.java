package fr.unice.l3.android_tp01;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

// 2 le surnom est fourni par une instance de la
// 2 classe *Préférences* (créée dans le *onCreate*),
public class Préférences {
    // 2 Pour l’instant, le surnom sera « écrit » en dur dans le code.

    public static final String SURNOM = "surnom";

    private String surnom = "TAZI";

    // 2 via une méthode *obtenirSurnom* et .
    public String obtenirSurnom() {
        return surnom;
    }
    // 2  *changerSurnom*.
    public void changerSurnom(String surnom) {
        this.surnom = surnom;
    }

    private String serveur = "10.0.2.2";
    private String port = "10101";

    public static final String SERVEUR = "serveur";

    public static final String PORT = "port";


    public Intent obtenirRéglages(Context context) {
        Intent i = new Intent(context, Reglages.class);
        i.putExtra(SURNOM, obtenirSurnom());

        i.putExtra(SERVEUR, obtenirServeur());
        i.putExtra(PORT, obtenirPort());
        return i;
    }

    public boolean reçoit(Intent data) {
        boolean ok = false;

        String nouveau = data.getStringExtra(SURNOM);

        String nouveauServeur = data.getStringExtra(SERVEUR);
        String nouveauPort = data.getStringExtra(PORT);

        if ((nouveau != null) && (!nouveau.equals(""))) {
            changerSurnom(nouveau);
            ok = true;}

        if ((nouveauServeur != null) && (!nouveauServeur.equals(""))) {
            changerServeur(nouveauServeur);
            ok = true;
        }

        if ((nouveauPort != null) && (!nouveauPort.equals(""))) {
            changerPort(nouveauPort);
            ok = true;
        }
        return ok;
    }

    public String obtenirServeur() { return serveur; }
    public String obtenirPort() { return port; }
    public void changerServeur(String serveur) { this.serveur = serveur; }
    public void changerPort(String port) { this.port = port; }

    public void saveIn(Bundle b) {
        b.putString(SURNOM, obtenirSurnom());
        b.putString(SERVEUR, obtenirServeur());
        b.putString(PORT, obtenirPort());
    }

    public void restoreFrom(Bundle b) {
        changerSurnom(b.getString(SURNOM));
        changerServeur(b.getString(SERVEUR));
        changerPort(b.getString(PORT));
    }


}
