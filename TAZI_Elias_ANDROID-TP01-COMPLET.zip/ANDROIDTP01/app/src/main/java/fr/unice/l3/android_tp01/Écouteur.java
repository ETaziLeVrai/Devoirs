package fr.unice.l3.android_tp01;


import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;

// 3 format des messages pour le serveur
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
// 3 Ce serveur utilise socketIO pour communiquer
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

// 2 Pour cela, créer une classe *Ecouteur*, qui implémente *OnClickListener*.
public class Écouteur implements View.OnClickListener,
// 3 Elle puisse recevoir les événements « onCheckedChanged » lié au switch « connexion ». Il
// 3 s’agit de l’interface CompoundButton.OnCheckedChangeListener.
        CompoundButton.OnCheckedChangeListener,
// 3 Elle gère donc la Socket de socketIO : connexion, déconnexion, réception de message sur
// 3 « chatevent » (implémente Emitter.Listener)
        Emitter.Listener {
    // 2  Déterminez les attributs qui lui
    // 2  sont nécessaires pour pouvoir récupérer le texte *message*, l’ajouter en fin de *chat* et faire
    // 2baisser le *scroll*.
    private Chat chat;
    // 3 Ce serveur utilise socketIO pour communiquer
    private Socket socket;
    // 3 Il faut que Ecouteur ait accès aux préférences (via constructeur ou via setter)
    // 3 pour préciser le userName lors de l’envoi de message.
    private Préférences préférences;

    // 2 Le constructeur de *Ecouteur* prend un *Chat* en paramètre
    // 2 public Écouteur(Chat chat, Préférences préférences) {
    // 3 préférences pour le surnom
    public Écouteur(Chat chat, Préférences préférences) {
        setChat(chat);
        // 3 Il faut que Ecouteur ait accès aux préférences (via constructeur ou via setter)
        // 3 pour préciser le userName lors de l’envoi de message.
        setPréférences(préférences);
        try {
            // 3 Un serveur (minimaliste) est disponible sur la machine « tpsi.unice.fr »
            // 3 (adresse IP : 134.59.2.27) sur le port 10101.
            // 3 Le paramètre pour créer la socket avec IO est donc : « http://134.59.2.27:10101 »
            // 3 Note : si le serveur tourne sur la même machine qu’un émulateur android
            // 3 sur lequel vous faites vos essais,
            // 3 l’adresse du serveur pour le client android est alors : 10.0.2.2, et
            // 3 le serveur tourne alors en local (127.0.0.1)
            socket = IO.socket("http://88.160.63.150:40102");
            // 3 Outre la connexion, il accepte les messages suivants : « chatevent »
            // 3 Dans un premier temps, vous n’utiliserez (en émission et réception) que
            // 3 les message « chatevent »
            socket.on("chatevent", this);
            // 4 il faut que le traitement passe par Ecouteur, mais vous êtes libres de choisir
            // 4 l’implémentation (classe anonyme, autre classe, etc.) pour écouter le message « connected list ».
            socket.on("connected list", new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    JSONObject data = (JSONObject) args[0];
                    try {
                        // 4 On reçoit alors un tableau
                        // 4 des connectés : le nom de l’attribut est « connected » et
                        // 4 la valeur est un tableau JSON
                        JSONArray connected = data.getJSONArray("connected");
                        String list = "\n***** connecté(s) ******\n";
                        for (int i = 0; i < connected.length(); i++) {
                            list += connected.get(i).toString() + "\n";
                        }
                        list += "\n*******************\n";
                        getChat().ajouterMessage(list, Color.RED);
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                }
            });
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    // 2 Déterminez les attributs qui lui
    // 2 sont nécessaires pour pouvoir récupérer le texte *message*, l’ajouter en fin de *chat* et faire
    // 2 baisser le *scroll*.
    @Override
    public void onClick(View v) {
        // 2 Dans le onClick, Ecouteur utilise les méthodes définies dans Chat
        String msg = chat.obtenirTextTapé();
        // 3 Quand le bouton « envoyer » est utilisé, le message n’est plus affiché directement
        // 2 chat.ajouterMessage(msg);
        // 3 Outre la connexion, il accepte les messages suivants :
        // 3 « chatevent » et le JSon attendu est alors { userName : "un nom" ; message : "le message"}
        if (socket != null) {
            // 3 mais émis vers le serveur : « chatevent » et le JSon attendu est alors { userName : "un
            // 3 nom" ; message : "le message"}
            JSONObject obj = new JSONObject();
            try {
                obj.put("userName", préférences.obtenirSurnom());
                obj.put("message", msg);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            socket.emit("chatevent", obj);
        }
    }

    public void setChat(Chat chat) {
        this.chat = chat;
    }

    public Chat getChat() {
        return chat;
    }

    // 3 Elle puisse recevoir les événements « onCheckedChanged » lié au switch « connexion ». Il
    // 3 s’agit de l’interface CompoundButton.OnCheckedChangeListener.
    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        Log.e(ChatActivity.LOG, "switch " + isChecked);
        if (isChecked) {
            connexion();
        } else {
            deconnexion();
        }
        chat.activerIHM(isChecked);

    }

    // 3 Il faut que Ecouteur ait accès aux préférences (via constructeur ou via setter)
    // 3 pour préciser le userName lors de l’envoi de message.
    public void setPréférences(Préférences préférences) {
        this.préférences = préférences;
    }

    // 3 Il faut que Ecouteur ait accès aux préférences (via constructeur ou via setter)
    // 3 pour préciser le userName lors de l’envoi de message.
    public Préférences getPréférences() {
        return préférences;
    }

    // 3 la réception du message “chatevent” se fait sur thread de “socketIO”, il n’y a alors
    // 3 pas accès aux éléments graphiques et l’appel à la méthode ajouterMessage provoque une
    // 3 exception :
    @Override
    public void call(Object... args) {
        JSONObject data = (JSONObject) args[0];
        try {
            final String username = data.getString("userName");
            final String message = data.getString("message");
            chat.ajouterMessage(username + " > " + message + "\n");
        } catch (JSONException e) {
            Log.e(ChatActivity.LOG, "JSONException");
            return;
        }
    }

    // 3 La connexion et déconnexion doivent se faire dans des méthodes séparées.
    public void deconnexion() {
        if (socket != null) socket.disconnect();
    }

    // 4 demande de la liste des connectés
    public void demandeListesConnectés() {
        if (socket != null) {
            socket.emit("queryconnected");
        }
    }

    private void créerConnexion() {
        try {
            socket = IO.socket("http://" +
                    getPréférences().obtenirServeur() + ":" +
                    getPréférences().obtenirPort());
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    public void connexion () {
        if (socket == null) {
            créerConnexion();
        }
        socket.connect();
        chat.activerIHM(true);

    }

    public void changerConnexion ( boolean connexion){
        deconnexion();
        créerConnexion();
        if (connexion) connexion();
    }

}
