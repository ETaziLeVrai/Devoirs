package fr.unice.j3.android_tp01;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;

public class ChatActivity extends Activity implements Chat {
    Button envoyer;
    EditText message;
    ScrollView scroll;
    TextView chat;

    Preferences preferences;
    Ecouteur ecouteur;
    Switch connexion;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        envoyer = findViewById(R.id.envoyer);
        message = findViewById(R.id.message);
        scroll = findViewById(R.id.scroll);
        chat = findViewById(R.id.chat);

        preferences = new Preferences();
        Ecouteur ecouteur=new Ecouteur(this, preferences);
        envoyer.setOnClickListener(ecouteur);

        connexion = findViewById(R.id.connexion);
        connexion.setOnCheckedChangeListener(ecouteur);

    }

    @Override
    public String obtenirTextTapé() {
        String texte = message.getText().toString();
        message.setText("");
        return texte;
    }

    @Override
    public void  ajouterMessage(String msg) {
        runOnUiThread(new Runnable() {} );


    public void onPause() {
        super.onPause();
        ecouteur.deconnexion();
    }

    public void onResume() {
        super.onResume();
        if (connexion.isChecked()) ecouteur.connexion();
    }



}
}