package fr.unice.j3.android_tp01;

import android.view.View;
import android.widget.CompoundButton;
import org.json.JSONException;
import org.json.JSONObject;

// Apparement Il faut importer ceci mais cela ne semble pas marcher

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;


public class Ecouteur implements View.OnClickListener{

    private Chat chat;
    private Socket socket;
    private Preferences preferences;

    public Chat getChat() {
        return chat;
    }

    public void setChat(Chat chat) {
        this.chat = chat;
    }

    public Preferences getPreferences() {
        return preferences;
    }

    public void setPreferences(Preferences preferences) {
        this.preferences = preferences;
    }


    public Ecouteur(Chat chat, Preferences preferences) {
        setChat(chat);
        setPreferences(preferences);

        try {
            socket = IO.socket("http://134.59.2.27:10101");
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Le catch a été généré automatiquement et je ne sais pas trop ce que veux dire printStackTrace()
    }

    @Override
    public void onClick(View v) {
        String msg = chat.obtenirTextTapé();

        if (socket != null) {
            JSONObject obj = new JSONObject();
            try {
                obj.put("userName", preferences.obtenirSurnom());
                obj.put("message", msg);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
    public void onClick(View view) {
        chat.ajouterMessage(chat.obtenirTextTapé());
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            connexion();
        } else {
            deconnexion();
        }
    }

    @Override
    public void call(Object... args) {
        JSONObject data = (JSONObject) args[0];
        try {
            final String username = data.getString("userName");
            final String message = data.getString("message");
            chat.ajouterMessage(username + ": " + message);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void deconnexion() {
       socket.disconnect();
    }

    public void connexion() {
        socket.connect();
    }

    }
