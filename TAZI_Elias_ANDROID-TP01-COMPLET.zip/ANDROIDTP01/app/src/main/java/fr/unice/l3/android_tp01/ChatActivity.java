package fr.unice.l3.android_tp01;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class ChatActivity extends Activity implements Chat {
    // pour LOG
    public static final String LOG = "TP-ANDROID-CHAT";
    // 2 <--
    EditText message;
    TextView chat;
    ScrollView scroll;
    Button envoyer;
    Préférences prefs;
    // -->
    // 3 <--
    Écouteur écouteur;
    Switch connexion;

    private static final int CODE_REGLAGES = 42;

    // 3 -->
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 2 <--
        setContentView(R.layout.activity_chat);
        message = findViewById(R.id.message);
        chat = findViewById(R.id.chat);
        scroll = findViewById(R.id.scroll);
        envoyer = findViewById(R.id.envoyer);
        // 3 Elle puisse recevoir les événements « onCheckedChanged » lié
        // 3 au switch « connexion »
        connexion = findViewById(R.id.connexion);
        // 2 Ce surnom est fourni par une instance de la classe Préférences (créée dans le onCreate)
        prefs = new Préférences();
        // 2 Écouteur écouteur = new Écouteur(this);
        // 3 écouteur partagée avec onPause et onResume
        écouteur = new Écouteur(this, prefs);
        // 2 Cet écouteur devra être associé à « envoyez » dans le onCreate de l’activité.
        envoyer.setOnClickListener(écouteur);
        // 3 Elle puisse recevoir les événements « onCheckedChanged » lié au switch « connexion
        connexion.setOnCheckedChangeListener(écouteur);

        prefs = new Préférences();

        if (savedInstanceState != null)
            prefs.restoreFrom(savedInstanceState);

    }

    @Override
    public String obtenirTextTapé() {
        // 2 via une méthode *obtenirSurnom*
        // 2 String texte = prefs.obtenirSurnom() + " > " + message.getText() + "\n";
        // 3 le message émis au serveur contient le sur nom
        String texte = message.getText().toString();
        message.setText("");
        return texte;
    }

    // 4 Ce message doit apparaitre en rouge dans le texte. Pour cela ajoutez une méthode
    // 4 (les paramètres sont « final » pour être utiliser dans un runOnUIThread) :
    // 4
    public void ajouterMessage(final String msg, final int couleur) {
        // 4 Cette méthode utilisera une SpannableString comme suit :
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                SpannableString formaté = new SpannableString(msg);
                formaté.setSpan(new ForegroundColorSpan(couleur), 0, msg.length(), 0);
                // 4 « formaté » peut alors être ajouter à une TextView
                chat.append(formaté);
                // 2 Pour faire « descendre » scroll, il faut utiliser une ligne de code ressemblent à
                scroll.fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    // 3 la réception du message “chatevent” se fait sur thread de “socketIO”, il n’y a alors
    // 3 pas accès aux éléments graphiques et l’appel à la méthode ajouterMessage provoque une
    // 3 exception :
    @Override
    public void ajouterMessage(final String msg) {
        // 3 Pour éviter ce problème, il faut modifier la méthode ajouterMessage de ChatActivity en encapsulant
        // 3 son contenu dans un « runOnUIThread(new Runnable() { /* etc. */ }) ; ».
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                chat.append(msg);
                // 2 Pour faire « descendre » scroll, il faut utiliser une ligne de code ressemblent à
                scroll.fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    // 3 Pour ne pas consommer pendant que l’application n’est pas utilisée, il faut prévoir la déconnexion
    // 3 sur le onPause de ChatActivity et
    // 3 de rétablir la connexion dans le onResume si le switch connexion est sélectionné.
    @Override
    public void onPause() {
        super.onPause();
        écouteur.deconnexion();
    }

    // 3 de rétablir la connexion dans le onResume si le switch connexion est sélectionné.
    @Override
    public void onResume() {
        super.onResume();
        if (connexion.isChecked()) écouteur.connexion();

        activerIHM(connexion.isChecked());

    }

    public void activerIHM(boolean checked) {

        message.setEnabled(checked);

        envoyer.setEnabled(checked);
    }

    // 4 Vous devez ajouter un item dans le menu pour lancer une demande (envoi de « queryconnected »
    // 4 avec un objet JSON vide au serveur). Pour ajouter le menu, implémentez deux méthodes :
    // 4 onCreateOptionMenu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        Log.e(LOG, "onCreateOptionsMenu");
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.chat, menu);
        return true;
    }

    // 4 puis onOptionsItemSelected pour écouter les évènements sur le menu.
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.listesconnectes) {
            écouteur.demandeListesConnectés();
        } else if (item.getItemId() == R.id.reglages) {

            startActivityForResult(prefs.obtenirRéglages(this), CODE_REGLAGES);
        }
        return true;
    }

    @Override
    public void onActivityResult(int requestcode, int resultcode, Intent data) {
        if (requestcode == CODE_REGLAGES) {
            if (resultcode == Activity.RESULT_OK) {
                boolean correct = prefs.reçoit(data);

                if (!correct) {
                    Toast t = Toast.makeText(this, "réglages vides... non pris en compte", Toast.LENGTH_SHORT);
                    t.show();
                } else {

                    écouteur.changerConnexion(connexion.isChecked());
                }
            }
        }
    }


    @Override
    public void onSaveInstanceState(Bundle saved) {
        super.onSaveInstanceState(saved);
        CharSequence seq = chat.getText();
        saved.putCharSequence("chat", seq);
        prefs.saveIn(saved);
    }


    @Override
    public void onRestoreInstanceState(Bundle saved) {
        super.onRestoreInstanceState(saved);
        chat.append(saved.getCharSequence("chat"));
    }


}
