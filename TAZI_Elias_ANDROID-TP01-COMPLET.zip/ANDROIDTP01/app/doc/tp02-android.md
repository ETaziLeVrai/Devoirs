<!-- Required extensions: toc sane_lists markdown mathjax smarty codehilite -->
[TOC]
#TP01 Android : Chat
##séance 1 : TP1 -- 18/03/2021 - 2 Heures
###étape 1 -- Faire le projet et le 1<sup>er</sup> layout
Une fois le projet généré, renommez *MainActivity* en *ChatActiviy*, changez l’extends (de
*AppCompatActivity* en *Activity*), 
~~~java
package fr.unice.l3.android.tp01;
import android.app.Activity;
import android.os.Bundle;

public class ChatActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
    }
}
~~~
renommez également le fichier *layout/activity_main.xml* en
*activity_chat* <del>.layout</del>. Vous devez obtenir alors un projet semblable à la Figure 1 (sauf qu’il est avec un
*ConstraintLayout*)
Optionnel : changer le *ConstraintLayout* en *RelativeLayout* (plus simple)
>Component tree
CD, convert view...

Supprimer le *textView* par défaut

~~~ xml
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:id="@+id/relativeLayout"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".ChatActivity">
</RelativeLayout>
~~~
Il contient un *Switch* (bouton à état), Le switch doit avoir comme texte **connexion**  défini comme une ressource et un id **connexion**.
~~~ xml
    <Switch
        android:id="@+id/connexion"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_alignParentTop="true"
        android:layout_alignParentStart="true"
        android:text="@string/connexion" />
~~~

un *EditText* (pour saisir du texte),  
l’élément doit avoir l’id **message**, pas de texte par défaut, sa largeur doit être en
*match_parent* (sans déborder sur le bouton), un *hint* qui est **tapez votre message**
(valeur du texte non pas directement dans le layout mais en utilisant une ressource *string*
value »)
~~~ xml
    <EditText
        android:id="@+id/message"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_below="@id/connexion"
        android:layout_alignParentStart="true"
        android:ems="10"
        android:hint="@string/tapez_votre_message"
        android:inputType="text"
        android:autofillHints="" />
~~~
un Button, Le bouton doit avec le texte **envoyez**, texte défini comme une ressource avec  un id **envoyer**
~~~ xml
   <Button
        android:id="@+id/envoyer"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="@string/envoyer"
        android:layout_below="@id/connexion"
        android:layout_alignParentEnd="true" />
~~~  
et un *ScrollView* contenant un *TextView*. ce container doit avoir l’id **scroll**
la zone de texte doit avoir l’id **chat**
~~~ xml
    <ScrollView
        android:id="@+id/scroll"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:layout_below="@id/message">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical">

            <TextView
                android:id="@+id/chat"
                android:layout_width="match_parent"
                android:layout_height="wrap_content" />
        </LinearLayout>
    </ScrollView>
~~~

~~~ plantuml 
@startuml
class toto{}
@enduml
~~~

::uml:: format="png" classes="uml myDiagram" alt="My super diagram placeholder" title="My super diagram" width="300px" height="300px"
      Goofy ->  MickeyMouse: calls
      Goofy <-- MickeyMouse: responds
::end-uml::

On accepte les fix proposés par Android Studio !  
Dans la vue Design, on obtient  
![](componentTree.md.png)










